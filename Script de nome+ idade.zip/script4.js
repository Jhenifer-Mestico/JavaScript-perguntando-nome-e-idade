var nome = prompt("Qual o seu nome?");   
var idade = prompt("Qual a sua idade?");   /* caixa alta OK*/
var mensagem = ("Nome digitado:" + nome +  "Idade digitada:"+ idade);
document.write("<p>" + mensagem + "<p>"); /*mostrar num parágrafo e concatenar*/
